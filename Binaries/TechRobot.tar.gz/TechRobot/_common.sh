DIR="$(cd "$(dirname "$0")" && pwd -P)"
export LD_LIBRARY_PATH="$DIR/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
TEAM="TechRobot"; HOST="localhost"; PORT=6000; CPORT=""; NUM=11; COACH=true
POSITIONAL_HOST=false
case "$(basename "$0")" in start1|start2|start3) ALLOW_POSITIONAL_HOST=true ;; *) ALLOW_POSITIONAL_HOST=false ;; esac
valid_uint_range () {
  [[ "$1" =~ ^[0-9]+$ ]] && (( 10#$1 >= $2 && 10#$1 <= $3 ))
}
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--host|-p|--port|-P|--coach-port|-t|--teamname|-n|--number)
      [ $# -ge 2 ] && [ -n "$2" ] && [[ "$2" != -* ]] || exit 2
      case "$1" in
        -h|--host) HOST="$2" ;;
        -p|--port) PORT="$2" ;;
        -P|--coach-port) CPORT="$2" ;;
        -t|--teamname) TEAM="$2" ;;
        -n|--number) NUM="$2" ;;
      esac
      shift 2 ;;
    -C|--without-coach) COACH=false; shift ;;
    -*) exit 2 ;;
    *)
      [ "$ALLOW_POSITIONAL_HOST" = true ] && [ "$POSITIONAL_HOST" = false ] && [ -n "$1" ] || exit 2
      HOST="$1"; POSITIONAL_HOST=true; shift ;;
  esac
done
valid_uint_range "$PORT" 1 65535 || exit 2
[ -z "$CPORT" ] || valid_uint_range "$CPORT" 1 65535 || exit 2
valid_uint_range "$NUM" 1 11 || exit 2
[ -n "$CPORT" ] || CPORT=$((PORT+2))
valid_uint_range "$CPORT" 1 65535 || exit 2
OPT=(-h "$HOST" -p "$PORT" -t "$TEAM" --player-config "$DIR/player.conf" --config_dir "$DIR/formations-dt")
run_player () { "$DIR/sample_player" "${OPT[@]}" "$@" </dev/null >/dev/null 2>&1 & }
run_coach () { "$DIR/sample_coach" -h "$HOST" -p "$CPORT" -t "$TEAM" --coach-config "$DIR/coach.conf" </dev/null >/dev/null 2>&1 & }
