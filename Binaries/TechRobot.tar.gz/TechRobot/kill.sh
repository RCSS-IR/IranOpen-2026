#!/bin/bash
# Stop only executables whose resolved path belongs to this package.
DIR="$(cd "$(dirname "$0")" && pwd -P)"
stop_agents () {
  local proc exe pid
  for proc in /proc/[0-9]*/exe; do
    exe=$(readlink "$proc" 2>/dev/null) || continue
    # Rosetta exposes its interpreter as /proc/PID/exe on Apple Silicon.
    if [ "$exe" = /run/rosetta/rosetta ]; then
      IFS= read -r -d "" exe < "${proc%/exe}/cmdline" || continue
    fi
    case "$exe" in
      "$DIR/sample_player"|"$DIR/sample_coach")
        pid=${proc#/proc/}; pid=${pid%/exe}
        kill -"$1" "$pid" 2>/dev/null || true ;;
    esac
  done
}
stop_agents TERM
sleep 1
stop_agents KILL
exit 0
